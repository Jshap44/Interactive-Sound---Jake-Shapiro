{
    "name": "LiveVideo",
    "version": 1,
    "creationdate": 3857735506,
    "modificationdate": 3857742283,
    "viewrect": [ 25.0, 118.0, 300.0, 500.0 ],
    "autoorganize": 1,
    "hideprojectwindow": 0,
    "showdependencies": 1,
    "autolocalize": 0,
    "contents": {
        "patchers": {
            "LiveVideo.maxpat": {
                "kind": "patcher",
                "local": 1,
                "toplevel": 1
            }
        },
        "media": {
            "duck.aiff": {
                "kind": "audiofile",
                "local": 1,
                "singleton": {
                    "bootpath": "~/Desktop",
                    "projectrelativepath": ".."
                }
            },
            "00248=30033=27232=25656.mp4": {
                "kind": "moviefile",
                "local": 1,
                "singleton": {
                    "bootpath": "~/Desktop/ATLS 4221/MaxMSP/VizzieTutorial/media",
                    "projectrelativepath": "../ATLS 4221/MaxMSP/VizzieTutorial/media"
                }
            }
        },
        "code": {        }
    },
    "layout": {    },
    "searchpath": {    },
    "detailsvisible": 0,
    "amxdtype": 0,
    "readonly": 0,
    "devpathtype": 0,
    "devpath": ".",
    "sortmode": 0,
    "viewmode": 0,
    "includepackages": 0
}