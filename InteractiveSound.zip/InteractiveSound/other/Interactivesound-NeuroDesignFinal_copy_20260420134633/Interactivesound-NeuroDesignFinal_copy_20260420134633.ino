#include <Arduino.h>
#include <Arduino_BMI270_BMM150.h>

const int FLEX_PINS[] = {A0, A1, A2, A3, A4};

void setup() {
  Serial.begin(115200);
  while (!Serial) {}

  if (!IMU.begin()) {
    Serial.println("IMU failed");
    while (1) {}
  }

  for (int i = 0; i < 5; i++) {
    pinMode(FLEX_PINS[i], INPUT);
  }
}

void loop() {
  if (!IMU.accelerationAvailable()) return;

  float ax, ay, az;
  IMU.readAcceleration(ax, ay, az);

  Serial.print(ax, 4); Serial.print(' ');
  Serial.print(ay, 4); Serial.print(' ');
  Serial.print(az, 4); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[0])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[1])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[2])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[3])); Serial.print(' ');
  Serial.println(analogRead(FLEX_PINS[4]));
}