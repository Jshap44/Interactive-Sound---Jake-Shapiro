#include <Arduino.h>
#include <Arduino_BMI270_BMM150.h>

const int FLEX_PINS[] = {A0, A1, A2, A3, A4};

// Gravity bias for dot product
float gx_bias = 0.0f;
float gy_bias = 0.0f;
float gz_bias = 0.0f;
const float BIAS_ALPHA = 0.95f;

void setup() {
  Serial.begin(115200);
  while (!Serial) {}

  if (!IMU.begin()) {
    Serial.println("IMU failed");
    while (1) {}
  }

  for (int i = 0; i < 5; i++) {
    pinMode(FLEX_PINS[i], INPUT);
  }
}

void loop() {
  if (!IMU.accelerationAvailable()) return;

  float ax, ay, az;
  IMU.readAcceleration(ax, ay, az);

  // Update gravity bias
  gx_bias = BIAS_ALPHA * gx_bias + (1.0f - BIAS_ALPHA) * ax;
  gy_bias = BIAS_ALPHA * gy_bias + (1.0f - BIAS_ALPHA) * ay;
  gz_bias = BIAS_ALPHA * gz_bias + (1.0f - BIAS_ALPHA) * az;

  // Subtract gravity
  float mx = ax - gx_bias;
  float my = ay - gy_bias;
  float mz = az - gz_bias;

  // Dot product to get downward value
  float gMag = sqrt(gx_bias*gx_bias + gy_bias*gy_bias + gz_bias*gz_bias);
  float downward = 0.0f;
  if (gMag > 0.1f) {
    downward = (mx*gx_bias + my*gy_bias + mz*gz_bias) / gMag;
  }

  Serial.print(ax, 4); Serial.print(' ');
  Serial.print(ay, 4); Serial.print(' ');
  Serial.print(az, 4); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[0])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[1])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[2])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[3])); Serial.print(' ');
  Serial.print(analogRead(FLEX_PINS[4])); Serial.print(' ');
  Serial.println(downward, 4);
}